<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App;
class ControlPaginas extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('welcome');
    }

    public function registro(){

        $registro = App\Registro::all();

        return view('registro', compact('registro'));
    // return view('registro');

    }
    public function detalle($id){

    //Aquí valida si existe sino redirije al 404
    $registro = App\Registro::findOrFail($id);

    return view('registro.detalle', compact('registro'));
}

    public function ingresar(Request $request){
        // return $request->all();

        $ingresoNuevo = new App\Registro;
        $ingresoNuevo->nombre = $request->nombre;
        $ingresoNuevo->apellido = $request->apellido;
        $ingresoNuevo->correo = $request->correo;
        $ingresoNuevo->telefono = $request->telefono;
        $ingresoNuevo->ciudad = $request->ciudad;
        $ingresoNuevo->sexo = $request->sexo;
        $ingresoNuevo->edad = $request->edad;

        $ingresoNuevo->save();

        return back()->with('mensaje', 'Datos agregados');
       
    }

    public function noticia(){
            return view('noticia');

    }
    public function nosotros(){
    return view('nosotros');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
