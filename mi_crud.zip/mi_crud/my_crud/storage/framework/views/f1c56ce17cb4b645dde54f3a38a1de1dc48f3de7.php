<?php $__env->startSection('seccion'); ?>
<h1>Bienvenido a Este sitio web</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mi_crud\my_crud\resources\views/welcome.blade.php ENDPATH**/ ?>