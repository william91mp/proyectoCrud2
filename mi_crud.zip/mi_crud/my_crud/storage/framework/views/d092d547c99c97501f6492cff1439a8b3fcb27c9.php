
<?php $__env->startSection('seccion'); ?>
<h1>pagina nosotros</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mi_crud\my_crud\resources\views/nosotros.blade.php ENDPATH**/ ?>