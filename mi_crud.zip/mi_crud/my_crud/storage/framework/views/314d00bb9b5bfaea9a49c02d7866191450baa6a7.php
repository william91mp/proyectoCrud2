
<?php $__env->startSection('seccion'); ?>
<h1>pagina para ingresar datos</h1>

<!--<form>
  <?php echo csrf_field(); ?>
  <input type="text"  placeholder="Nombre" class="form-control mb-2">
  <input type="text"  placeholder="Descripcion" class="form-control mb-2">
  <button class="btn btn-primary" type="submit">Agregar</button>
  </div>
</form>-->


<form action="<?php echo e(route('registro.ingresar')); ?>" method="POST">
  <?php echo csrf_field(); ?>  
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputName4"><?php echo e('Nombre'); ?></label>
      <input type="text" name="nombre" class="form-control"  placeholder="Nombre">
    </div>

    <div class="form-group col-md-6">
      <label for="inputApe4">Apellido</label>
      <input type="text" name="apellido" class="form-control"  placeholder="Apellido">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail4">Email</label>
      <input type="email" name="correo" class="form-control"  placeholder="Email">
    
  </div>
  <div class="form-group">
    <label for="inputTelefono4">Telefono</label>
      <input type="number" name="telefono" class="form-control"  placeholder="Telefono">
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputciudad4">Ciudad</label>
      <input type="text" name="ciudad" class="form-control"  placeholder="Ciudad">
    </div>
    <div class="form-group col-md-4">
       <label for="inputSexo">Sexo</label>
      <input type="text" name="sexo" class="form-control"  placeholder="Sexo">
    </div>

    <div class="form-group col-md-2">
     <label for="inputEdad">Edad</label>
      <input type="number" name="edad" class="form-control"  placeholder="Edad">
    </div>
  </div>
  
  </div>
  <button type="submit" class="btn btn-primary">Agregar</button>
</form>

<table class="table table-dark">

  <thead>

    <tr>
      <th scope="col">#ID</th>
      <th scope="col">NOMBRE</th>
      <th scope="col">APELLIDO</th>
      <th scope="col">E-MAIL</th>
      <th scope="col">#TELEFONO</th>
      <th scope="col">CIUDAD</th>
      <th scope="col">SEXO</th>
      <th scope="col">EDAD</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $registro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($item->id); ?></th>
      <td>
        <a href="<?php echo e(route('registro.detalle', $item)); ?>"><?php echo e($item->nombre); ?></a>
      </td>
      
      <td><?php echo e($item->apellido); ?></td>
      <td><?php echo e($item->correo); ?></td>
      <td><?php echo e($item->telefono); ?></td>
      <td><?php echo e($item->ciudad); ?></td>
      <td><?php echo e($item->sexo); ?></td>
      <td><?php echo e($item->edad); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mi_crud\my_crud\resources\views/registro.blade.php ENDPATH**/ ?>