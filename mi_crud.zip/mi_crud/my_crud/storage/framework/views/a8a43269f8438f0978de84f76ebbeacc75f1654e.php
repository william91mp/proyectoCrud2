<?php $__env->startSection('seccion'); ?>
<h1>Detalle</h1>
<hr />
<h4>Id: <?php echo e($registro->id); ?></h4>
<h4>Nombre: <?php echo e($registro->nombre); ?></h4>
<h4>Apellido: <?php echo e($registro->apellido); ?></h4>
<h4>correo: <?php echo e($registro->correo); ?></h4>
<h4>telefono: <?php echo e($registro->telefono); ?></h4>
<h4>ciudad: <?php echo e($registro->ciudad); ?></h4>
<h4>sexo: <?php echo e($registro->sexo); ?></h4>
<h4>edad: <?php echo e($registro->edad); ?></h4>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\mi_crud\my_crud\resources\views/registro/detalle.blade.php ENDPATH**/ ?>