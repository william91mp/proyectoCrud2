@extends('plantilla')
@section('seccion')
<h1>Bienvenido a Este sitio web</h1>
@endsection