@extends('plantilla')
@section('seccion')
<h1>pagina de las noticias</h1>
@endsection