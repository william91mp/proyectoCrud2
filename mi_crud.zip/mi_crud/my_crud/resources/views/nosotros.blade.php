@extends('plantilla')
@section('seccion')
<h1>pagina nosotros</h1>
@endsection