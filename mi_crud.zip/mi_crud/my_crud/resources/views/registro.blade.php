@extends('plantilla')
@section('seccion')
<h1>pagina para ingresar datos</h1>

<!--<form>
  @csrf
  <input type="text"  placeholder="Nombre" class="form-control mb-2">
  <input type="text"  placeholder="Descripcion" class="form-control mb-2">
  <button class="btn btn-primary" type="submit">Agregar</button>
  </div>
</form>-->


<form action="{{ route('registro.ingresar') }}" method="POST">
  @csrf  
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputName4">{{'Nombre'}}</label>
      <input type="text" name="nombre" class="form-control"  placeholder="Nombre">
    </div>

    <div class="form-group col-md-6">
      <label for="inputApe4">Apellido</label>
      <input type="text" name="apellido" class="form-control"  placeholder="Apellido">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail4">Email</label>
      <input type="email" name="correo" class="form-control"  placeholder="Email">
    
  </div>
  <div class="form-group">
    <label for="inputTelefono4">Telefono</label>
      <input type="number" name="telefono" class="form-control"  placeholder="Telefono">
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputciudad4">Ciudad</label>
      <input type="text" name="ciudad" class="form-control"  placeholder="Ciudad">
    </div>
    <div class="form-group col-md-4">
       <label for="inputSexo">Sexo</label>
      <input type="text" name="sexo" class="form-control"  placeholder="Sexo">
    </div>

    <div class="form-group col-md-2">
     <label for="inputEdad">Edad</label>
      <input type="number" name="edad" class="form-control"  placeholder="Edad">
    </div>
  </div>
  
  </div>
  <button type="submit" class="btn btn-primary">Agregar</button>
</form>

<table class="table table-dark">

  <thead>

    <tr>
      <th scope="col">#ID</th>
      <th scope="col">NOMBRE</th>
      <th scope="col">APELLIDO</th>
      <th scope="col">E-MAIL</th>
      <th scope="col">#TELEFONO</th>
      <th scope="col">CIUDAD</th>
      <th scope="col">SEXO</th>
      <th scope="col">EDAD</th>
    </tr>
  </thead>
  <tbody>
    @foreach($registro as $item)
    <tr>
      <th scope="row">{{ $item->id }}</th>
      <td>
        <a href="{{route('registro.detalle', $item)}}">{{ $item->nombre }}</a>
      </td>
      
      <td>{{ $item->apellido }}</td>
      <td>{{ $item->correo }}</td>
      <td>{{ $item->telefono }}</td>
      <td>{{ $item->ciudad }}</td>
      <td>{{ $item->sexo }}</td>
      <td>{{ $item->edad }}</td>
    </tr>
    @endforeach
  </tbody>
</table>
@endsection