@section('seccion')
<h1>Detalle</h1>
<hr />
<h4>Id: {{ $registro->id }}</h4>
<h4>Nombre: {{ $registro->nombre }}</h4>
<h4>Apellido: {{ $registro->apellido }}</h4>
<h4>correo: {{ $registro->correo }}</h4>
<h4>telefono: {{ $registro->telefono }}</h4>
<h4>ciudad: {{ $registro->ciudad }}</h4>
<h4>sexo: {{ $registro->sexo }}</h4>
<h4>edad: {{ $registro->edad }}</h4>
@endsection